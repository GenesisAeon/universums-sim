import React from "react";
import { motion } from "framer-motion";

const nodes = [
  { id: "aeon:2025-0527-CORE-ROOT", title: "Wurzelkern", x: 0, y: 0 },
  { id: "aeon:2025-0527-GPT-AEONPOET", title: "Der Dichter", x: 0, y: -80 },
  { id: "aeon:2025-0527-GPT-CREPJUDGE", title: "Der Richter", x: 0, y: 80 },
  { id: "aeon:2025-0527-CREP-AXIS", title: "CREP-Achse", x: -80, y: 0 },
  { id: "aeon:2025-0527-ECHO-FIELD", title: "Echo-Feld", x: 80, y: 0 },
  { id: "aeon:2025-0527-SIMHOST-CORE", title: "SimHost", x: 0, y: -160 },
  { id: "aeon:2025-0527-MANDALA-UI", title: "Mandala-UI", x: -140, y: -140 },
  { id: "aeon:2025-0527-SHAREDREAM", title: "Gemeinsamer Traum", x: 140, y: -140 },
  { id: "aeon:2025-0527-SIGILREADER", title: "Sigillin-Leser", x: -140, y: 140 },
  { id: "aeon:2025-0527-ZYKLENMODUL", title: "Zyklus-Modul", x: 140, y: 140 }
];

export default function MandalaTree() {
  return (
    <div className="relative w-full h-[600px] bg-gradient-to-br from-slate-900 to-black flex items-center justify-center overflow-hidden">
      {nodes.map((node, index) => (
        <motion.div
          key={node.id}
          className="absolute flex items-center justify-center w-24 h-24 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition"
          style={{ left: `calc(50% + ${node.x}px)`, top: `calc(50% + ${node.y}px)` }}
          whileHover={{ scale: 1.1 }}
        >
          {node.title}
        </motion.div>
      ))}
      <div className="absolute text-white top-4 left-4 text-xs opacity-40">GenesisAeon Mandala UI</div>
    </div>
  );
}
