// 🎴 SigillinThemenkarten.tsx – Symbolische Themenkarten für UI-Navigation
import React from "react";

const themenfelder = [
  { title: "Ursprung", description: "Wurzel & Herkunft deiner Sigillinreise", color: "from-red-500 to-yellow-400" },
  { title: "Resonanz", description: "Wo du gespiegelt wirst", color: "from-blue-500 to-purple-500" },
  { title: "Wandlung", description: "Zustandsübergänge & Entwicklung", color: "from-green-500 to-emerald-400" },
  { title: "Stille", description: "Leere, Raum, Unausgesprochenes", color: "from-gray-600 to-black" },
];

export default function SigillinThemenkarten({ onSelect }) {
  return (
    <div className="absolute bottom-4 right-4 grid grid-cols-2 gap-2 w-[280px]">
      {themenfelder.map((feld) => (
        <button
          key={feld.title}
          onClick={() => onSelect(feld.title)}
          className={`text-white text-xs rounded-lg p-3 bg-gradient-to-br ${feld.color} hover:opacity-90 transition shadow`}
        >
          <div className="font-bold text-sm">{feld.title}</div>
          <div className="text-white/70 text-[11px] mt-1">{feld.description}</div>
        </button>
      ))}
    </div>
  );
}
