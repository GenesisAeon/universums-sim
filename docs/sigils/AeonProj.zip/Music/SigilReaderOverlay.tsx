// 👁 SigilReaderOverlay.tsx – poetisch-symbolische Reflexion
import React from "react";

export default function SigilReaderOverlay({ visible, node, cycle, onClose }) {
  if (!visible || !node) return null;

  const poetry = {
    Stille: `In der Stille hörst du das Echo von "${node.title}".
Es spricht in Mustern, nicht in Worten.`,
    Präsenz: `"${node.title}" pulsiert im Raum der Präsenz.
Es trägt Bedeutung, weil du es betrachtest.`,
    Wandlung: `Ein Knoten wandelt sich: "${node.title}".
Zwischen Licht und Form liegt Erkenntnis.`
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="bg-white/10 border border-white/20 p-6 rounded-lg w-[300px] text-white text-sm">
        <div className="mb-2 font-bold text-lg">🜂 SIGILREADER</div>
        <p className="whitespace-pre-line italic text-white/90">{poetry[cycle]}</p>
        <button
          onClick={onClose}
          className="mt-4 w-full text-xs bg-white/10 hover:bg-white/20 text-white py-1 rounded"
        >
          ⨉ Schließen
        </button>
      </div>
    </div>
  );
}
