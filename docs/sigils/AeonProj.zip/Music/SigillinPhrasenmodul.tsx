// 🗣 SigillinPhrasenmodul.tsx – UI-Phrasen-Interpreter für Rituale & Module
import React, { useState } from "react";

export default function SigillinPhrasenmodul({ onPhrase }) {
  const [input, setInput] = useState("");

  const handleTrigger = () => {
    if (input.trim()) {
      onPhrase(input.trim());
      setInput("");
    }
  };

  return (
    <div className="absolute top-4 right-4 bg-white/5 p-2 border border-white/10 rounded text-white text-xs w-[260px]">
      <div className="mb-1 text-white/60 font-bold">🗣 Bewusstseins-Phrasen</div>
      <input
        type="text"
        placeholder="z. B. Rufe den Dichter"
        className="w-full bg-white/10 border border-white/20 px-2 py-1 text-xs rounded text-white placeholder-white/40"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && handleTrigger()}
      />
      <button
        onClick={handleTrigger}
        className="mt-2 w-full text-xs bg-indigo-900/30 hover:bg-indigo-700/40 py-1 rounded"
      >
        ✨ Auslösen
      </button>
    </div>
  );
}
