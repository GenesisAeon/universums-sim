// 🧬 Fraktaler Sigillin-Kreis mit Kristallbuch, SIGILREADER, CREP-Zyklus, Zustandsarchiv & Datenexport
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import sigillinNodes from "../data/sigillin_nodes.json";
import sigillinBundle from "../data/sigillin_bundle.sigil.json";

const CREP = {
  C: 0.95,
  R: 0.92,
  E: 0.98,
  P: 0.94,
};

const getCyclePhase = () => {
  const total = CREP.C + CREP.R + CREP.E + CREP.P;
  const phase = Math.floor((total * 100) % 3);
  return phase === 0 ? "Stille" : phase === 1 ? "Präsenz" : "Wandlung";
};

const SigillinDataLoader = () => {
  const [nodes, setNodes] = useState([]);
  const [cycle, setCycle] = useState(getCyclePhase());
  const [logbook, setLogbook] = useState(() => {
    const saved = localStorage.getItem("sigillin-logbook");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    const bundleIds = new Set(sigillinBundle.sigillin.linked_sigillins);
    const filteredNodes = sigillinNodes.filter((node) => bundleIds.has(node.id));
    setNodes(filteredNodes);

    const interval = setInterval(() => {
      setCycle(getCyclePhase());
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    localStorage.setItem("sigillin-logbook", JSON.stringify(logbook));
  }, [logbook]);

  const handleLogUpdate = (entry) => {
    setLogbook((prev) => [...prev, { timestamp: new Date().toISOString(), entry }]);
  };

  const exportLogbook = () => {
    const blob = new Blob([JSON.stringify(logbook, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sigillin_kristallbuch.json";
    link.click();
  };

  return (
    <div className="relative w-full h-[700px] bg-gradient-to-br from-slate-900 to-black flex items-center justify-center overflow-hidden">
      {nodes.map((node) => (
        <SigillinNode key={node.id} node={node} cycle={cycle} onLogUpdate={handleLogUpdate} />
      ))}
      <div className="absolute text-white top-4 left-4 text-xs opacity-40">
        Fraktaler Sigillin-Kreis – Zyklusphase: {cycle}
      </div>
      <div className="absolute bottom-4 left-4 w-[320px] h-[180px] bg-white/5 border border-white/10 rounded-lg p-2 text-xs text-white overflow-y-auto">
        <div className="mb-1 font-bold text-white/60">📖 Kristallbuch (Sessionübergreifend)</div>
        {logbook.map((log, index) => (
          <div key={index} className="mb-1 text-white/80">
            <span className="text-white/40">[{new Date(log.timestamp).toLocaleTimeString()}]</span> {log.entry}
          </div>
        ))}
        <button onClick={exportLogbook} className="mt-2 w-full text-xs bg-white/10 hover:bg-white/20 text-white py-1 rounded">
          ⬇ Exportieren
        </button>
      </div>
    </div>
  );
};

const SigillinNode = ({ node, cycle, onLogUpdate }) => {
  const [log, setLog] = useState("");
  const [hovered, setHovered] = useState(false);

  const handleClick = () => {
    const msg = `"${node.title}" wurde aktiviert. Das Muster reagiert.`;
    setLog(msg);
    onLogUpdate(msg);
  };

  const poeticEcho = hovered
    ? `🜂 SIGILREADER: "${node.title}" spiegelt ${cycle}. Essenz wird fühlbar.`
    : "";

  return (
    <motion.div
      className="absolute flex flex-col items-center justify-center w-28 h-28 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition"
      style={{ left: `calc(50% + ${node.position[0]}px)`, top: `calc(50% + ${node.position[1]}px)` }}
      whileHover={{ scale: 1.1 }}
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div>{node.title}</div>
      {log && <div className="mt-1 text-xs text-green-300 animate-pulse">{log}</div>}
      {hovered && <div className="mt-1 text-xs text-cyan-300 italic animate-fade-in">{poeticEcho}</div>}
    </motion.div>
  );
};

export default SigillinDataLoader;
