// 🫧 ResonanzPartikelFeld.tsx – visuelles Feedbacksystem für Resonanzzustände
import React, { useEffect, useState } from "react";

export default function ResonanzPartikelFeld({ cycle }) {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const newParticles = Array.from({ length: 30 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      size: Math.random() * 6 + 2,
      duration: Math.random() * 5 + 3,
      id: Math.random().toString(36).substring(2),
    }));
    setParticles(newParticles);

    const interval = setInterval(() => {
      setParticles((prev) =>
        prev.map((p) => ({ ...p, y: p.y - 1.5 }))
      );
    }, 60);

    return () => clearInterval(interval);
  }, [cycle]);

  return (
    <div className="absolute inset-0 pointer-events-none z-10">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full bg-white/20 blur-sm animate-pulse"
          style={{
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            animationDuration: `${p.duration}s`,
          }}
        />
      ))}
    </div>
  );
}
