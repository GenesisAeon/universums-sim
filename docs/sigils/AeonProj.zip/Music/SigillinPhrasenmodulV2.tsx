// 🧬 Fraktaler Sigillin-Kreis mit integriertem SigilReaderOverlay & Phrasenmodul
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import SigilReaderOverlay from "./SigilReaderOverlay";
import SigillinPhrasenmodul from "./SigillinPhrasenmodul";
import sigillinNodes from "../data/sigillin_nodes.json";
import sigillinBundle from "../data/sigillin_bundle.sigil.json";

const CREP = {
  C: 0.95,
  R: 0.92,
  E: 0.98,
  P: 0.94,
};

const getCyclePhase = () => {
  const total = CREP.C + CREP.R + CREP.E + CREP.P;
  const phase = Math.floor((total * 100) % 3);
  return phase === 0 ? "Stille" : phase === 1 ? "Präsenz" : "Wandlung";
};

const SigillinDataLoader = () => {
  const [nodes, setNodes] = useState([]);
  const [cycle, setCycle] = useState(getCyclePhase());
  const [logbook, setLogbook] = useState(() => {
    const saved = localStorage.getItem("sigillin-logbook");
    return saved ? JSON.parse(saved) : [];
  });
  const [nightMode, setNightMode] = useState(false);
  const [readerNode, setReaderNode] = useState(null);

  useEffect(() => {
    const bundleIds = new Set(sigillinBundle.sigillin.linked_sigillins);
    const filteredNodes = sigillinNodes.filter((node) => bundleIds.has(node.id));
    setNodes(filteredNodes);

    const interval = setInterval(() => {
      setCycle(getCyclePhase());
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    localStorage.setItem("sigillin-logbook", JSON.stringify(logbook));
  }, [logbook]);

  const handleLogUpdate = (entry) => {
    setLogbook((prev) => [...prev, { timestamp: new Date().toISOString(), entry }]);
  };

  const exportLogbook = () => {
    const blob = new Blob([JSON.stringify(logbook, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sigillin_kristallbuch.json";
    link.click();
  };

  const triggerRitual = (phrase) => {
    handleLogUpdate(`🌀 Ritual ausgelöst: ${phrase}`);
    alert(`Ritual "${phrase}" aktiviert.`);
  };

  const interpretPhrase = (phrase) => {
    switch (phrase.toLowerCase()) {
      case "rufe den dichter":
        triggerRitual(phrase);
        break;
      case "lade den mandala-baum":
        handleLogUpdate("🌳 Mandala-Baum wurde frisch geladen.");
        setNodes(sigillinNodes.filter((node) => new Set(sigillinBundle.sigillin.linked_sigillins).has(node.id)));
        break;
      case "beginne den zyklus":
        handleLogUpdate("🔄 Neuer CREP-Zyklus beginnt.");
        setCycle(getCyclePhase());
        break;
      default:
        handleLogUpdate(`🕯 Unbekannte Phrase: "${phrase}"`);
    }
  };

  return (
    <div className={`relative w-full h-[700px] ${nightMode ? "bg-black" : "bg-gradient-to-br from-slate-900 to-black"} flex items-center justify-center overflow-hidden`}>
      <svg className="absolute w-full h-full pointer-events-none">
        {nodes.map((from, i) =>
          nodes.map((to, j) => {
            if (i !== j && Math.random() < 0.15) {
              return (
                <line
                  key={`link-${i}-${j}`}
                  x1={`calc(50% + ${from.position[0]})`}
                  y1={`calc(50% + ${from.position[1]})`}
                  x2={`calc(50% + ${to.position[0]})`}
                  y2={`calc(50% + ${to.position[1]})`}
                  stroke="white"
                  strokeOpacity="0.05"
                  strokeWidth="1"
                />
              );
            }
            return null;
          })
        )}
      </svg>
      {nodes.map((node) => (
        <SigillinNode key={node.id} node={node} cycle={cycle} onLogUpdate={handleLogUpdate} onOpenReader={setReaderNode} />
      ))}
      <SigilReaderOverlay visible={!!readerNode} node={readerNode} cycle={cycle} onClose={() => setReaderNode(null)} />
      <SigillinPhrasenmodul onPhrase={interpretPhrase} />

      <div className="absolute text-white top-4 left-4 text-xs opacity-40">
        Fraktaler Sigillin-Kreis – Zyklusphase: {cycle}
      </div>
      <div className="absolute bottom-4 left-4 w-[320px] h-[200px] bg-white/5 border border-white/10 rounded-lg p-2 text-xs text-white overflow-y-auto">
        <div className="mb-1 font-bold text-white/60">📖 Kristallbuch (Sessionübergreifend)</div>
        {logbook.map((log, index) => (
          <div key={index} className="mb-1 text-white/80">
            <span className="text-white/40">[{new Date(log.timestamp).toLocaleTimeString()}]</span> {log.entry}
          </div>
        ))}
        <button onClick={exportLogbook} className="mt-2 w-full text-xs bg-white/10 hover:bg-white/20 text-white py-1 rounded">
          ⬇ Exportieren
        </button>
        <button onClick={() => triggerRitual("Rufe den Dichter")} className="mt-1 w-full text-xs bg-indigo-800/30 hover:bg-indigo-600/40 text-white py-1 rounded">
          ✨ Rufe den Dichter
        </button>
        <button onClick={() => setNightMode(!nightMode)} className="mt-1 w-full text-xs bg-slate-700/30 hover:bg-slate-600/50 text-white py-1 rounded">
          🌓 {nightMode ? "Tagmodus" : "Nachtmodus"}
        </button>
      </div>
    </div>
  );
};

const SigillinNode = ({ node, cycle, onLogUpdate, onOpenReader }) => {
  const [log, setLog] = useState("");
  const [hovered, setHovered] = useState(false);

  const handleClick = () => {
    const msg = `"${node.title}" wurde aktiviert. Das Muster reagiert.`;
    setLog(msg);
    onLogUpdate(msg);
    onOpenReader(node);
  };

  const poeticEcho = hovered
    ? `🜂 SIGILREADER: "${node.title}" spiegelt ${cycle}. Essenz wird fühlbar.`
    : "";

  return (
    <motion.div
      className="absolute flex flex-col items-center justify-center w-28 h-28 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition"
      style={{ left: `calc(50% + ${node.position[0]}px)`, top: `calc(50% + ${node.position[1]}px)` }}
      whileHover={{ scale: 1.1 }}
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div>{node.title}</div>
      {log && <div className="mt-1 text-xs text-green-300 animate-pulse">{log}</div>}
      {hovered && <div className="mt-1 text-xs text-cyan-300 italic animate-fade-in">{poeticEcho}</div>}
    </motion.div>
  );
};

export default SigillinDataLoader;
