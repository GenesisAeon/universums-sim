// 📥📤 SigillinImportExport.tsx – Importiere & Exportiere Sigillin-Zustände
import React, { useRef } from "react";

export default function SigillinImportExport({ onImport }) {
  const fileRef = useRef();

  const handleImport = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target.result);
        if (Array.isArray(json)) {
          onImport(json);
        } else {
          alert("Die Datei enthält kein gültiges Sigillin-Array.");
        }
      } catch (err) {
        alert("Fehler beim Lesen der Datei.");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="absolute top-4 right-72 text-white text-xs">
      <div className="mb-1">📥 Symbolimport</div>
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        onChange={handleImport}
        className="text-white/60"
      />
    </div>
  );
}
