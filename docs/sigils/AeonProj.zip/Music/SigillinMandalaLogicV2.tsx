// 🧬 Fraktaler Sigillin-Kreis – mit CREP-Zyklus, SIGILREADER & Logbuchstruktur
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import sigillinNodes from "../data/sigillin_nodes.json";
import sigillinBundle from "../data/sigillin_bundle.sigil.json";

const CREP = {
  C: 0.95,
  R: 0.92,
  E: 0.98,
  P: 0.94,
};

const getCyclePhase = () => {
  const total = CREP.C + CREP.R + CREP.E + CREP.P;
  const phase = Math.floor((total * 100) % 3);
  return phase === 0 ? "Stille" : phase === 1 ? "Präsenz" : "Wandlung";
};

const SigillinDataLoader = () => {
  const [nodes, setNodes] = useState([]);
  const [cycle, setCycle] = useState(getCyclePhase());

  useEffect(() => {
    const bundleIds = new Set(sigillinBundle.sigillin.linked_sigillins);
    const filteredNodes = sigillinNodes.filter((node) => bundleIds.has(node.id));
    setNodes(filteredNodes);

    const interval = setInterval(() => {
      setCycle(getCyclePhase());
    }, 10000); // simulate cycle every 10 sec

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full h-[700px] bg-gradient-to-br from-slate-900 to-black flex items-center justify-center overflow-hidden">
      {nodes.map((node) => (
        <SigillinNode key={node.id} node={node} cycle={cycle} />
      ))}
      <div className="absolute text-white top-4 left-4 text-xs opacity-40">
        Fraktaler Sigillin-Kreis – Zyklusphase: {cycle}
      </div>
    </div>
  );
};

const SigillinNode = ({ node, cycle }) => {
  const [log, setLog] = useState("");
  const [hovered, setHovered] = useState(false);

  const handleClick = () => {
    setLog(`"${node.title}" wurde aktiviert. Das Muster reagiert.`);
  };

  const poeticEcho = hovered
    ? `🜂 SIGILREADER: "${node.title}" spiegelt ${cycle}. Essenz wird fühlbar.`
    : "";

  return (
    <motion.div
      className="absolute flex flex-col items-center justify-center w-28 h-28 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition"
      style={{ left: `calc(50% + ${node.position[0]}px)`, top: `calc(50% + ${node.position[1]}px)` }}
      whileHover={{ scale: 1.1 }}
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div>{node.title}</div>
      {log && <div className="mt-1 text-xs text-green-300 animate-pulse">{log}</div>}
      {hovered && <div className="mt-1 text-xs text-cyan-300 italic animate-fade-in">{poeticEcho}</div>}
    </motion.div>
  );
};

export default SigillinDataLoader;
