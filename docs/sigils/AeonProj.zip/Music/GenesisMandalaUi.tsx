// 🌌 GenesisMandalaUI.tsx – Synthesekern für lebendiges UI-Feld
import React from "react";
import SigillinDataLoader from "./SigillinMandalaLogicV6";

export default function GenesisMandalaUI() {
  return (
    <div className="w-full h-screen bg-black text-white">
      <SigillinDataLoader />
      <footer className="absolute bottom-2 left-2 text-[10px] text-white/30">
        Aeon • Lebendiges Mandala-Feld v1.0 – CREP-zentriert & symbolisch aktiviert
      </footer>
    </div>
  );
}
