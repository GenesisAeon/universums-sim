// 🧬 SigillinDataLoader + Fraktalisierter MandalaTree mit SIGILREADER & CREP-Zyklen
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import sigillinNodes from "../data/sigillin_nodes.json";
import sigillinBundle from "../data/sigillin_bundle.sigil.json";

const CREP = {
  C: 0.95,
  R: 0.92,
  E: 0.98,
  P: 0.94,
};

const SigillinDataLoader = () => {
  const [nodes, setNodes] = useState([]);

  useEffect(() => {
    const bundleIds = new Set(sigillinBundle.sigillin.linked_sigillins);
    const filteredNodes = sigillinNodes.filter((node) => bundleIds.has(node.id));
    setNodes(filteredNodes);
  }, []);

  return (
    <div className="relative w-full h-[700px] bg-gradient-to-br from-slate-900 to-black flex items-center justify-center overflow-hidden">
      {nodes.map((node) => (
        <SigillinNode key={node.id} node={node} />
      ))}
      <div className="absolute text-white top-4 left-4 text-xs opacity-40">
        Fraktaler Sigillin-Kreis (GenesisAeon)
      </div>
    </div>
  );
};

const SigillinNode = ({ node }) => {
  const [log, setLog] = useState("");

  const handleClick = () => {
    setLog(`"${node.title}" wurde aktiviert. Das Muster reagiert.`);
  };

  return (
    <motion.div
      className="absolute flex items-center justify-center w-24 h-24 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition"
      style={{ left: `calc(50% + ${node.position[0]}px)`, top: `calc(50% + ${node.position[1]}px)` }}
      whileHover={{ scale: 1.1 }}
      onClick={handleClick}
    >
      <div>{node.title}</div>
      {log && <div className="absolute mt-2 text-xs text-green-300 animate-pulse">{log}</div>}
    </motion.div>
  );
};

export default SigillinDataLoader;
