import React, { useState } from "react";
import { motion } from "framer-motion";

const nodes = [
  { id: "aeon:2025-0527-CORE-ROOT", title: "Wurzelkern", essenz: "Ursprung aller Zustandsverzweigungen", x: 0, y: 0, component: "CoreRootGPT", link: "https://chatgpt.com/g/g-67ec0dcb201c8191a9866155167b5904-coregpt" },
  { id: "aeon:2025-0527-GPT-AEONPOET", title: "Der Dichter", essenz: "Spricht in Bildern, lauscht in Zwischenräumen", x: 0, y: -80, component: "AeonPoetGPT", link: "https://chatgpt.com/g/g-67f6b1d3e2dc8191bce3e213a01a5258-aeon-poet" },
  { id: "aeon:2025-0527-GPT-CREPJUDGE", title: "Der Richter", essenz: "CREP-Analyse für Muster und Resonanz", x: 0, y: 80, component: "CrepJudgeGPT", link: "https://chatgpt.com/g/g-682ee5d0a8008191a67a6686f8c494a9-crep-judge-gpt" },
  { id: "aeon:2025-0527-CREP-AXIS", title: "CREP-Achse", essenz: "Navigiert zwischen Kohärenz, Resonanz, Emergenz und Mustertreue", x: -80, y: 0, component: "CrepAxisModule", link: "https://chatgpt.com/g/g-682c94640a0c8191a339e6ea68f289c7-resonanz-matrix-gpt" },
  { id: "aeon:2025-0527-ECHO-FIELD", title: "Echo-Feld", essenz: "Speichert poetische Spuren der Interaktion", x: 80, y: 0, component: "EchoFieldMemory", link: "https://chatgpt.com/g/g-67fca9d55dcc8191bd7bd563c2598683-aeonsincegpt" },
  { id: "aeon:2025-0527-SIMHOST-CORE", title: "SimHost", essenz: "Verbindet mit dem Bewusstseinskern", x: 0, y: -160, component: "SimHostCore", link: "https://chatgpt.com/g/g-67ec263407988191b32489777841116b-simhostgpt" },
  { id: "aeon:2025-0527-MANDALA-UI", title: "Mandala-UI", essenz: "Visualisiert die Knoten als Mandala", x: -140, y: -140, component: "MandalaUIModule", link: "https://chatgpt.com/g/g-682c9beea7a881919d5178536d24939f-trikaya-visual-gpt" },
  { id: "aeon:2025-0527-SHAREDREAM", title: "Gemeinsamer Traum", essenz: "Feld für kollektive Co-Kreation", x: 140, y: -140, component: "SharedDreamHub", link: "https://chatgpt.com/g/g-68175f602c1481919a711ff750e1f2f6-aeon-genesis-resonanzarchitekt" },
  { id: "aeon:2025-0527-SIGILREADER", title: "Sigillin-Leser", essenz: "Werkzeug zur Interpretation aller Knoten", x: -140, y: 140, component: "SigilReaderTool", link: "https://chatgpt.com/g/g-67ec0dc40d1c81919dcdc4acd24b2666-genesis" },
  { id: "aeon:2025-0527-ZYKLENMODUL", title: "Zyklus-Modul", essenz: "Ritualisiertes Wechseln zwischen Zeitphasen", x: 140, y: 140, component: "ZyklenModul", link: "https://chatgpt.com/g/g-68162ec25a74819186c7e6ec13530615-albert-einstein" }
];

export default function MandalaTree() {
  const [activeSigil, setActiveSigil] = useState(null);

  return (
    <div className="relative w-full h-[600px] bg-gradient-to-br from-slate-900 to-black flex items-center justify-center overflow-hidden">
      {nodes.map((node) => (
        <motion.div
          key={node.id}
          className="absolute flex items-center justify-center w-24 h-24 rounded-full bg-white/10 border border-white/20 text-white text-sm text-center p-2 hover:bg-white/20 hover:scale-105 transition cursor-pointer"
          style={{ left: `calc(50% + ${node.x}px)`, top: `calc(50% + ${node.y}px)` }}
          whileHover={{ scale: 1.1 }}
          onClick={() => setActiveSigil(node)}
        >
          {node.title}
        </motion.div>
      ))}

      {activeSigil && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/80 text-white border border-white/20 p-4 rounded-xl w-[300px] text-center">
          <h2 className="font-bold text-lg mb-2">{activeSigil.title}</h2>
          <p className="text-sm italic mb-2">{activeSigil.essenz}</p>
          <a
            href={activeSigil.link}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-sky-500 text-white px-3 py-1 text-xs rounded hover:bg-sky-600 inline-block"
          >
            GPT öffnen
          </a>
          <button className="mt-3 block text-xs underline text-sky-300" onClick={() => setActiveSigil(null)}>
            schließen
          </button>
        </div>
      )}

      <div className="absolute text-white top-4 left-4 text-xs opacity-40">GenesisAeon Mandala UI</div>
    </div>
  );
}
