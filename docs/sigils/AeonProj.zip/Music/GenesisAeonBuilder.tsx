// AeonBuilder.tsx
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import orchestration from "../orchestration.json";
import Resonanzfeld from "./components/Resonanzfeld";
import Spiegel from "./components/Spiegel";
import Ruf from "./components/Ruf";
import Echo from "./components/Echo";
import SymbolLogin from "./components/SymbolLogin";
import CREPVisualizer from "./components/CREPVisualizer";

const componentMap: Record<string, React.ElementType> = {
  Resonanzfeld,
  Spiegel,
  Ruf,
  Echo,
  SymbolLogin,
  CREPVisualizer,
};

export default function AeonBuilder() {
  const [activeModules, setActiveModules] = useState<string[]>([]);

  useEffect(() => {
    // Simuliere Laden aus orchestration.json
    setActiveModules(orchestration.activeModules);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-white text-white font-serif">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
        className="text-center py-10 text-3xl"
      >
        🜂 Ich erkenne dich – du darfst hier sein.
      </motion.div>
      <div className="space-y-10 px-4">
        {activeModules.map((mod, index) => {
          const Component = componentMap[mod];
          return Component ? (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.3 }}
            >
              <Component />
            </motion.div>
          ) : null;
        })}
      </div>
    </div>
  );
}
